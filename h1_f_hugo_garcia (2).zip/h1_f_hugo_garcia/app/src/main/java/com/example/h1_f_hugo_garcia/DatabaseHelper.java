package com.example.h1_f_hugo_garcia;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.example.h1_f_hugo_garcia.Score;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "juego.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "estado_juego";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_PUNTOS = "puntos";
    private static final String COLUMN_MULTIPLICADOR = "multiplicador";
    private static final String COLUMN_NIVEL = "nivel";
    private static final String COLUMN_TOQUES = "toques";
    private static final String COLUMN_NOMBRE = "nombre";
    private static final String COLUMN_TIMESTAMP = "timestamp";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_PUNTOS + " INTEGER, " +
                COLUMN_MULTIPLICADOR + " INTEGER, " +
                COLUMN_NIVEL + " INTEGER, " +
                COLUMN_TOQUES + " INTEGER, " +
                COLUMN_NOMBRE + " TEXT, " +
                COLUMN_TIMESTAMP + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void insertScore(int puntos, String timestamp, String nombre, int nivel) {
        SQLiteDatabase db = this.getWritableDatabase();
        String insert = "INSERT INTO " + TABLE_NAME + " (" +
                COLUMN_PUNTOS + ", " +
                COLUMN_TIMESTAMP + ", " +
                COLUMN_NOMBRE + ", " +
                COLUMN_NIVEL + ") VALUES (" +
                puntos + ", '" +
                timestamp + "', '" +
                nombre + "', " +
                nivel + ")";
        db.execSQL(insert);
    }

    public void deleteScore(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_NAME + " WHERE " + COLUMN_ID + " = " + id);
    }

    public void saveGameState(int puntos, int multiplicador, int nivel, int toques, String nombre) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_NAME);
        String insert = "INSERT INTO " + TABLE_NAME + " (" +
                COLUMN_PUNTOS + ", " +
                COLUMN_MULTIPLICADOR + ", " +
                COLUMN_NIVEL + ", " +
                COLUMN_TOQUES + ", " +
                COLUMN_NOMBRE + ") VALUES (" +
                puntos + ", " +
                multiplicador + ", " +
                nivel + ", " +
                toques + ", '" +
                nombre + "')";
        db.execSQL(insert);
    }

    public List<Score> getAllScores() {
        List<Score> scores = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String select = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(select, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                int puntos = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_PUNTOS));
                String timestamp = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP));
                String nombre = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOMBRE));
                int nivel = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_NIVEL));
                scores.add(new Score(id, puntos, timestamp, nombre, nivel));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return scores;
    }

    public void exportToJson(String filePath) {
        SQLiteDatabase db = this.getReadableDatabase();
        String select = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(select, null);
        JSONArray jsonArray = new JSONArray();

        if (cursor.moveToFirst()) {
            do {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put(COLUMN_ID, cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                    jsonObject.put(COLUMN_PUNTOS, cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_PUNTOS)));
                    jsonObject.put(COLUMN_MULTIPLICADOR, cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MULTIPLICADOR)));
                    jsonObject.put(COLUMN_NIVEL, cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_NIVEL)));
                    jsonObject.put(COLUMN_TOQUES, cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_TOQUES)));
                    jsonObject.put(COLUMN_NOMBRE, cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOMBRE)));
                    jsonObject.put(COLUMN_TIMESTAMP, cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIMESTAMP)));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                jsonArray.put(jsonObject);
            } while (cursor.moveToNext());
        }
        cursor.close();

        try (FileWriter file = new FileWriter(filePath)) {
            file.write(jsonArray.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}