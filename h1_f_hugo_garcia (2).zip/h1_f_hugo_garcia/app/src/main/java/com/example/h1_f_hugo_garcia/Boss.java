package com.example.h1_f_hugo_garcia;

public class Boss {
    private int health;
    private int maxHealth;
    private int level;

    public Boss(int level) {
        this.level = level;
        this.maxHealth = level * 100;
        this.health = maxHealth;
    }

    public int getHealth() {
        return health;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public void takeDamage(int damage) {
        health -= damage;
    }

    public boolean isDefeated() {
        return health <= 0;
    }
}