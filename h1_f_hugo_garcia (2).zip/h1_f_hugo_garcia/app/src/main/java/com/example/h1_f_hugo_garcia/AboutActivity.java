package com.example.h1_f_hugo_garcia;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        EditText etName = findViewById(R.id.etName);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etMessage = findViewById(R.id.etMessage);
        Button btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();
            String message = etMessage.getText().toString();

            if (name.isEmpty() || email.isEmpty() || message.isEmpty()) {
                Toast.makeText(AboutActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto", "adrian.hermosillahiguera.23@campusfp.es", null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Contact Form Submission");
                emailIntent.putExtra(Intent.EXTRA_TEXT, "Name: " + name + "\nEmail: " + email + "\nMessage: " + message);
                startActivity(Intent.createChooser(emailIntent, "Send email..."));
            }
        });
    }
}