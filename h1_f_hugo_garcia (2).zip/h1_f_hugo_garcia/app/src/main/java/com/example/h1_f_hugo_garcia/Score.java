package com.example.h1_f_hugo_garcia;

public class Score {
    private int id;
    private int puntos;
    private String timestamp;
    private String nombre;
    private int nivel;

    public Score(int id, int puntos, String timestamp, String nombre, int nivel) {
        this.id = id;
        this.puntos = puntos;
        this.timestamp = timestamp;
        this.nombre = nombre;
        this.nivel = nivel;
    }

    public int getId() {
        return id;
    }

    public int getScore() {
        return puntos;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getPlayerName() {
        return nombre;
    }

    public int getLevel() {
        return nivel;
    }
}