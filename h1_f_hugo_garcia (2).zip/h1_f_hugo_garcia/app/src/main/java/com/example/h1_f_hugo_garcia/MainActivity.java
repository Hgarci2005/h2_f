package com.example.h1_f_hugo_garcia;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "MisPreferencias";
    private static final String PUNTOS_KEY = "puntos";
    private static final String MULTIPLICADOR_KEY = "multiplicador";
    private static final String NIVEL_KEY = "nivel";
    private static final String TOQUES_KEY = "toques";
    private static final String NOMBRE_KEY = "nombre";
    private int puntos;
    private int multiplicador;
    private int nivel;
    private int toques;
    private String nombreJugador;
    private DatabaseHelper dbHelper;
    private RelativeLayout rootLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        rootLayout = findViewById(R.id.rootLayout);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        puntos = prefs.getInt(PUNTOS_KEY, 0);
        multiplicador = prefs.getInt(MULTIPLICADOR_KEY, 1);
        nivel = prefs.getInt(NIVEL_KEY, 1);
        toques = prefs.getInt(TOQUES_KEY, 0);
        nombreJugador = prefs.getString(NOMBRE_KEY, "");

        Button btnRanking = findViewById(R.id.btnRanking);
        Button btnAbout = findViewById(R.id.btnAbout);
        Button btnGame = findViewById(R.id.btnGame);

        btnRanking.setText("Ranking");
        btnAbout.setText("Acerca de");
        btnGame.setText("Juego");

        btnRanking.setOnClickListener(v -> {
            resetGameState();
            Intent intent = new Intent(MainActivity.this, RankingActivity.class);
            startActivity(intent);
        });

        btnAbout.setOnClickListener(v -> {
            resetGameState();
            Intent intent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(intent);
        });

        btnGame.setOnClickListener(v -> {
            resetGameState();
            Intent intent = new Intent(MainActivity.this, GameActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exportDatabaseToJson();
        resetGameState();
    }

    private void exportDatabaseToJson() {
        File folder = new File(getFilesDir(), "exports");
        if (!folder.exists()) {
            folder.mkdirs();
        }
        String filePath = new File(folder, "database_export.json").getAbsolutePath();
        dbHelper.exportToJson(filePath);
    }

    private void saveGameState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(PUNTOS_KEY, puntos);
        editor.putInt(MULTIPLICADOR_KEY, multiplicador);
        editor.putInt(NIVEL_KEY, nivel);
        editor.putInt(TOQUES_KEY, toques);
        editor.putString(NOMBRE_KEY, nombreJugador);
        editor.apply();

        dbHelper.saveGameState(puntos, multiplicador, nivel, toques, nombreJugador);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resetGameState();
    }

    private void resetGameState() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(PUNTOS_KEY, 0);
        editor.putInt(MULTIPLICADOR_KEY, 1);
        editor.putInt(NIVEL_KEY, 1);
        editor.putInt(TOQUES_KEY, 0);
        editor.putString(NOMBRE_KEY, "");
        editor.apply();
    }
}