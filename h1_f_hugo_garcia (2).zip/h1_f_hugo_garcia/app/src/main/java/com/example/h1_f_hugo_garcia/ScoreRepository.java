package com.example.h1_f_hugo_garcia;

import android.content.Context;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;

public class ScoreRepository {

    private DatabaseHelper dbHelper;

    public ScoreRepository(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void saveScore(int score, String playerName, int level) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        dbHelper.insertScore(score, timestamp, playerName, level);
    }

    public List<Integer> getAllScores() {
        List<Integer> scores = new ArrayList<>();
        List<Score> scoreList = dbHelper.getAllScores();

        for (Score score : scoreList) {
            scores.add(score.getScore());
        }

        return scores;
    }
}