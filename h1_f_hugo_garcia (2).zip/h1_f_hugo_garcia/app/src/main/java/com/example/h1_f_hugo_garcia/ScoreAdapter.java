package com.example.h1_f_hugo_garcia;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ScoreAdapter extends ArrayAdapter<Score> {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    private static final SimpleDateFormat DISPLAY_FORMAT = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    public ScoreAdapter(Context context, List<Score> scores) {
        super(context, 0, scores);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Score score = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_score, parent, false);
        }
        TextView scoreTextView = convertView.findViewById(R.id.scoreTextView);
        TextView timestampTextView = convertView.findViewById(R.id.timestampTextView);
        TextView playerNameTextView = convertView.findViewById(R.id.playerNameTextView);
        TextView levelTextView = convertView.findViewById(R.id.levelTextView);

        scoreTextView.setText(String.valueOf(score.getScore()));
        playerNameTextView.setText(score.getPlayerName());
        levelTextView.setText("Level: " + score.getLevel());
        if (score.getTimestamp() != null) {
            try {
                Date date = DATE_FORMAT.parse(score.getTimestamp());
                timestampTextView.setText(DISPLAY_FORMAT.format(date));
            } catch (ParseException e) {
                e.printStackTrace();
                timestampTextView.setText(score.getTimestamp());
            }
        } else {
            timestampTextView.setText("N/A");
        }

        return convertView;
    }
}