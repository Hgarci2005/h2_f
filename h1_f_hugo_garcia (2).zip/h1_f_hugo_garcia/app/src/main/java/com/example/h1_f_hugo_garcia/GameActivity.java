package com.example.h1_f_hugo_garcia;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class GameActivity extends AppCompatActivity {

    private int points;
    private int multiplier;
    private int level;
    private int tapCount;
    private Boss currentBoss;
    private CountDownTimer bossTimer;
    private DatabaseHelper dbHelper;
    private TextView pointsTextView;
    private TextView levelTextView;
    private TextView tapCountTextView;
    private TextView timerTextView;
    private TextView bossHealthTextView;
    private EditText playerNameEditText;
    private RelativeLayout rootLayout;
    private ImageView tapEffectView;
    private int pointsToNextLevel;
    private boolean bossFightStarted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        dbHelper = new DatabaseHelper(this);

        pointsTextView = findViewById(R.id.pointsTextView);
        levelTextView = findViewById(R.id.levelTextView);
        tapCountTextView = findViewById(R.id.tapCountTextView);
        timerTextView = findViewById(R.id.timerTextView);
        bossHealthTextView = findViewById(R.id.bossHealthTextView);
        playerNameEditText = findViewById(R.id.playerNameEditText);
        rootLayout = findViewById(R.id.rootLayout);
        tapEffectView = findViewById(R.id.tapEffectView);

        resetGame();
        updateUI();

        Button btnHome = findViewById(R.id.btnHome);
        Button btnUpgrade1 = findViewById(R.id.btnUpgrade1);
        Button btnUpgrade2 = findViewById(R.id.btnUpgrade2);
        Button btnSaveGame = findViewById(R.id.btnSaveGame);

        btnHome.setOnClickListener(v -> {
            Intent intent = new Intent(GameActivity.this, MainActivity.class);
            startActivity(intent);
        });

        btnUpgrade1.setOnClickListener(v -> {
            if (points >= 10) {
                points -= 10;
                multiplier *= 2;
                updateUI();
            }
        });

        btnUpgrade2.setOnClickListener(v -> {
            if (points >= 20) {
                points -= 20;
                multiplier *= 2;
                updateUI();
            }
        });

        btnSaveGame.setOnClickListener(v -> {
            saveGame();
        });

        rootLayout.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                if (!bossFightStarted) {
                    points += multiplier;
                } else {
                    attackBoss(multiplier);
                }
                tapCount++;
                showTapEffect(event.getX(), event.getY());
                updateUI();
            }
            return true;
        });
    }

    private void showTapEffect(float x, float y) {
        tapEffectView.setX(x - tapEffectView.getWidth() / 2);
        tapEffectView.setY(y - tapEffectView.getHeight() / 2);
        tapEffectView.setVisibility(View.VISIBLE);
        new Handler().postDelayed(() -> tapEffectView.setVisibility(View.GONE), 500);
    }

    private void saveGame() {
        new Thread(() -> {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            String playerName = playerNameEditText.getText().toString();
            dbHelper.insertScore(points, timestamp, playerName, level);
        }).start();
    }

    private void updateUI() {
        pointsTextView.setText("Points: " + points);
        levelTextView.setText("Level: " + level);
        tapCountTextView.setText("Taps: " + tapCount);
        if (points >= pointsToNextLevel && !bossFightStarted) {
            startBossFight(level);
        }
        if (currentBoss != null && !currentBoss.isDefeated()) {
            bossHealthTextView.setVisibility(View.VISIBLE);
            bossHealthTextView.setText("Boss Health: " + currentBoss.getHealth());
            timerTextView.setVisibility(View.VISIBLE);
        } else {
            bossHealthTextView.setVisibility(View.GONE);
            timerTextView.setVisibility(View.GONE);
        }
    }

    private void startBossFight(int level) {
        currentBoss = new Boss(level);
        bossFightStarted = true;
        bossHealthTextView.setVisibility(View.VISIBLE);
        timerTextView.setVisibility(View.VISIBLE);
        updateUI();

        bossTimer = new CountDownTimer(60000, 1000) { // 60 seconds timer
            public void onTick(long millisUntilFinished) {
                timerTextView.setText("Time remaining: " + millisUntilFinished / 1000);
            }

            public void onFinish() {
                if (!currentBoss.isDefeated()) {
                    gameOver();
                }
            }
        }.start();
    }

    private void attackBoss(int damage) {
        currentBoss.takeDamage(damage);
        updateUI();
        if (currentBoss.isDefeated()) {
            bossTimer.cancel();
            bossFightStarted = false;
            new Handler().post(() -> {
                bossHealthTextView.setVisibility(View.GONE);
                timerTextView.setVisibility(View.GONE);
            });
            levelUp();
        }
    }


    private void levelUp() {
        level++;
        pointsToNextLevel += level * 100; // Example logic for points required to level up
        bossFightStarted = false;
        updateUI();
    }

    private void gameOver() {
        Toast toast = Toast.makeText(this, "Game Over! You failed to defeat the boss.", Toast.LENGTH_SHORT);
        TextView textView = new TextView(this);
        textView.setText("Game Over! You failed to defeat the boss.");
        textView.setTextSize(24); // Set the text size to be larger
        toast.setView(textView);
        toast.show();
        resetGame();
    }

    private void resetGame() {
        points = 0;
        multiplier = 1;
        level = 1;
        tapCount = 0;
        pointsToNextLevel = level * 100; // Example logic for points required to level up
        bossFightStarted = false;
        updateUI();
    }
}