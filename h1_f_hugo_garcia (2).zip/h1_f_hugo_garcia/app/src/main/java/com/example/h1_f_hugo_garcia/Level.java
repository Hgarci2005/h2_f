package com.example.h1_f_hugo_garcia;

public class Level {
    private int levelNumber;
    private int requiredPoints;

    public Level(int levelNumber, int requiredPoints) {
        this.levelNumber = levelNumber;
        this.requiredPoints = requiredPoints;
    }

    public int getLevelNumber() {
        return levelNumber;
    }

    public int getRequiredPoints() {
        return requiredPoints;
    }
}