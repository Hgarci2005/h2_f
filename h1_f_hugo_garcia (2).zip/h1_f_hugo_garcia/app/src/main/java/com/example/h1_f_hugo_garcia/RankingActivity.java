package com.example.h1_f_hugo_garcia;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class RankingActivity extends AppCompatActivity {

    private static final String TAG = "RankingActivity";
    private DatabaseHelper dbHelper;
    private ListView listView;
    private ScoreAdapter scoreAdapter;
    private Score selectedScore;
    private List<Score> scores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ranking);

        dbHelper = new DatabaseHelper(this);
        listView = findViewById(R.id.listView);
        Button btnDeleteGame = findViewById(R.id.btnDeleteGame);
        Spinner spinnerSort = findViewById(R.id.spinnerSort);

        scores = dbHelper.getAllScores();
        if (scores.isEmpty()) {
            Log.d(TAG, "No scores found in the database.");
        } else {
            Log.d(TAG, "Scores found: " + scores.size());
        }

        scoreAdapter = new ScoreAdapter(this, scores);
        listView.setAdapter(scoreAdapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            selectedScore = scoreAdapter.getItem(position);
            view.setSelected(true);
        });

        btnDeleteGame.setOnClickListener(v -> {
            if (selectedScore != null) {
                showDeleteConfirmationDialog(selectedScore);
            }
        });

        Button btnHome = findViewById(R.id.btnHome);
        btnHome.setText("Inicio");

        btnHome.setOnClickListener(v -> {
            Log.d(TAG, "Home button clicked");
            finish();
        });

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.sort_criteria, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSort.setAdapter(adapter);

        spinnerSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String criteria = (String) parent.getItemAtPosition(position);
                sortScores(criteria);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void showDeleteConfirmationDialog(Score score) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Score")
                .setMessage("Are you sure you want to delete this score?")
                .setPositiveButton(android.R.string.yes, (dialog, which) -> {
                    dbHelper.deleteScore(score.getId());
                    scoreAdapter.remove(score);
                    scoreAdapter.notifyDataSetChanged();
                    selectedScore = null;
                })
                .setNegativeButton(android.R.string.no, null)
                .show();
    }

    private void sortScores(String criteria) {
        switch (criteria) {
            case "Score":
                Collections.sort(scores, Comparator.comparingInt(Score::getScore).reversed());
                break;
            case "Date":
                Collections.sort(scores, Comparator.comparing(Score::getTimestamp).reversed());
                break;
            case "Player Name":
                Collections.sort(scores, Comparator.comparing(Score::getPlayerName));
                break;
        }
        scoreAdapter.notifyDataSetChanged();
    }
}